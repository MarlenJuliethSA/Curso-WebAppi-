﻿namespace WebApiAutores.Entidades
{
    public class Autor
    {
        public int id { get; set; }
        public string Nombre  { get; set; }
     
    }
}
